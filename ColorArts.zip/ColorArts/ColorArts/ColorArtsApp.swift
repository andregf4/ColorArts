//
//  ColorArtsApp.swift
//  ColorArts
//
//  Created by Andre Gerez Foratto on 12/05/24.
//

import SwiftUI

@main
struct ColorArtsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
